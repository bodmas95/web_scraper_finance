"""
XBRL Extraction Service
Fetches IFRS financial filings from filings.xbrl.org by LEI.
Parses xBRL-JSON facts into the standard extraction row format.
"""

import asyncio
import json
import logging
import re
from typing import Any

import httpx

from config import settings

logger = logging.getLogger(__name__)

# Statement classifier: IFRS concept short name → statement type
STATEMENT_MAP = {
    # Income Statement
    "Revenue": "income_statement", "RevenueFromContractsWithCustomers": "income_statement",
    "OtherIncome": "income_statement", "OtherOperatingIncome": "income_statement",
    "CostOfSales": "income_statement", "GrossProfit": "income_statement",
    "DistributionCosts": "income_statement", "AdministrativeExpense": "income_statement",
    "SellingGeneralAndAdministrativeExpense": "income_statement",
    "EmployeeBenefitsExpense": "income_statement",
    "DepreciationAndAmortisationExpense": "income_statement",
    "DepreciationAmortisationAndImpairmentLossReversalOfImpairmentLossRecognisedInProfitOrLoss": "income_statement",
    "ImpairmentLossRecognisedInProfitOrLoss": "income_statement",
    "RawMaterialsAndConsumablesUsed": "income_statement",
    "OtherOperatingExpense": "income_statement", "OperatingExpense": "income_statement",
    "ProfitLossFromOperatingActivities": "income_statement",
    "FinanceCosts": "income_statement", "FinanceIncome": "income_statement",
    "FinanceIncomeExpense": "income_statement",
    "ShareOfProfitLossOfAssociatesAccountedForUsingEquityMethod": "income_statement",
    "ProfitLossBeforeTax": "income_statement",
    "IncomeTaxExpenseContinuingOperations": "income_statement",
    "ProfitLoss": "income_statement",
    "ProfitLossAttributableToOwnersOfParent": "income_statement",
    "ProfitLossAttributableToNoncontrollingInterests": "income_statement",
    "BasicEarningsLossPerShare": "income_statement",
    "DilutedEarningsLossPerShare": "income_statement",
    "OtherExpenseByFunction": "income_statement",
    "OtherExpenseByNature": "income_statement",
    "InterestExpense": "income_statement",
    "ServicesExpense": "income_statement",
    "MiscellaneousOtherOperatingIncome": "income_statement",
    "MiscellaneousOtherOperatingExpense": "income_statement",
    "DepreciationRightOfUseAssets": "income_statement",
    # Balance Sheet - Assets
    "Assets": "balance_sheet", "NoncurrentAssets": "balance_sheet",
    "CurrentAssets": "balance_sheet", "Goodwill": "balance_sheet",
    "IntangibleAssetsOtherThanGoodwill": "balance_sheet",
    "PropertyPlantAndEquipment": "balance_sheet",
    "RightOfUseAssets": "balance_sheet", "RightofuseAssets": "balance_sheet",
    "InvestmentsAccountedForUsingEquityMethod": "balance_sheet",
    "DeferredTaxAssets": "balance_sheet",
    "NoncurrentFinancialAssets": "balance_sheet",
    "Inventories": "balance_sheet",
    "TradeAndOtherCurrentReceivables": "balance_sheet",
    "TradeReceivables": "balance_sheet",
    "CurrentTaxAssets": "balance_sheet",
    "CashAndCashEquivalents": "balance_sheet",
    "OtherCurrentAssets": "balance_sheet",
    "OtherNoncurrentAssets": "balance_sheet",
    # Balance Sheet - Liabilities & Equity
    "EquityAndLiabilities": "balance_sheet",
    "Equity": "balance_sheet",
    "EquityAttributableToOwnersOfParent": "balance_sheet",
    "NoncontrollingInterests": "balance_sheet",
    "IssuedCapital": "balance_sheet", "SharePremium": "balance_sheet",
    "RetainedEarnings": "balance_sheet",
    "Liabilities": "balance_sheet",
    "NoncurrentLiabilities": "balance_sheet", "CurrentLiabilities": "balance_sheet",
    "NoncurrentBorrowings": "balance_sheet", "CurrentBorrowings": "balance_sheet",
    "NoncurrentLeaseLiabilities": "balance_sheet",
    "CurrentLeaseLiabilities": "balance_sheet",
    "DeferredTaxLiabilities": "balance_sheet",
    "NoncurrentProvisions": "balance_sheet", "CurrentProvisions": "balance_sheet",
    "TradeAndOtherCurrentPayables": "balance_sheet",
    "OtherNoncurrentLiabilities": "balance_sheet",
    "OtherCurrentLiabilities": "balance_sheet",
    "CurrentTaxLiabilities": "balance_sheet",
    # Cash Flow
    "CashFlowsFromUsedInOperatingActivities": "cash_flow",
    "CashFlowsFromUsedInInvestingActivities": "cash_flow",
    "CashFlowsFromUsedInFinancingActivities": "cash_flow",
    "CashFlowsFromUsedInOperations": "cash_flow",
    "IncreaseDecreaseInCashAndCashEquivalents": "cash_flow",
    "AdjustmentsForDepreciationAndAmortisationExpense": "cash_flow",
    "AdjustmentsForImpairmentLossReversalOfImpairmentLossRecognisedInProfitOrLoss": "cash_flow",
    "AdjustmentsForFinanceCosts": "cash_flow",
    "AdjustmentsForIncomeTaxExpense": "cash_flow",
    "IncreaseDecreaseInWorkingCapital": "cash_flow",
    "IncomeTaxesPaid": "cash_flow",
    "InterestPaid": "cash_flow",
    "PurchaseOfPropertyPlantAndEquipment": "cash_flow",
    "PurchaseOfIntangibleAssets": "cash_flow",
    "AcquisitionOfSubsidiariesNetOfCashAcquired": "cash_flow",
    "ProceedsFromBorrowingsClassifiedAsFinancingActivities": "cash_flow",
    "RepaymentsOfBorrowingsClassifiedAsFinancingActivities": "cash_flow",
    "DividendsPaid": "cash_flow",
    "DividendsPaidClassifiedAsFinancingActivities": "cash_flow",
    "EffectOfExchangeRateChangesOnCashAndCashEquivalents": "cash_flow",
    "CashAndCashEquivalentsAtEndOfPeriod": "cash_flow",
    "CashAndCashEquivalentsAtBeginningOfPeriod": "cash_flow",
    "ProceedsFromDisposalOfPropertyPlantAndEquipment": "cash_flow",
    "AdjustmentsForProvisions": "cash_flow",
    "PaymentsOfLeaseLiabilitiesClassifiedAsFinancingActivities": "cash_flow",
    "InterestPaidClassifiedAsOperatingActivities": "cash_flow",
    "InterestPaidClassifiedAsFinancingActivities": "cash_flow",
    "IncomeTaxesPaidRefundClassifiedAsOperatingActivities": "cash_flow",
    "ProceedsFromIssuingShares": "cash_flow",
    "PaymentsToAcquireOrRedeemEntitysShares": "cash_flow",
}

# Fallback English labels for common IFRS concepts
CONCEPT_LABELS = {
    "Revenue": "Revenue",
    "RevenueFromContractsWithCustomers": "Revenue from contracts with customers",
    "CostOfSales": "Cost of sales",
    "GrossProfit": "Gross profit",
    "DistributionCosts": "Distribution costs",
    "AdministrativeExpense": "Administrative expenses",
    "SellingGeneralAndAdministrativeExpense": "SG&A expenses",
    "EmployeeBenefitsExpense": "Employee benefits expense",
    "DepreciationAndAmortisationExpense": "Depreciation and amortisation",
    "RawMaterialsAndConsumablesUsed": "Raw materials and consumables used",
    "OtherOperatingExpense": "Other operating expenses",
    "ProfitLossFromOperatingActivities": "Profit from operating activities",
    "FinanceCosts": "Finance costs",
    "FinanceIncome": "Finance income",
    "ProfitLossBeforeTax": "Profit before tax",
    "IncomeTaxExpenseContinuingOperations": "Income tax expense",
    "ProfitLoss": "Profit (loss)",
    "ProfitLossAttributableToOwnersOfParent": "Net income (parent)",
    "ProfitLossAttributableToNoncontrollingInterests": "Net income (NCI)",
    "Assets": "Total assets",
    "NoncurrentAssets": "Non-current assets",
    "CurrentAssets": "Current assets",
    "Goodwill": "Goodwill",
    "IntangibleAssetsOtherThanGoodwill": "Intangible assets",
    "PropertyPlantAndEquipment": "Property, plant and equipment",
    "RightOfUseAssets": "Right-of-use assets",
    "Inventories": "Inventories",
    "TradeAndOtherCurrentReceivables": "Trade and other receivables",
    "CashAndCashEquivalents": "Cash and cash equivalents",
    "Equity": "Total equity",
    "EquityAttributableToOwnersOfParent": "Equity (parent)",
    "Liabilities": "Total liabilities",
    "NoncurrentBorrowings": "Non-current borrowings",
    "CurrentBorrowings": "Current borrowings",
    "TradeAndOtherCurrentPayables": "Trade and other payables",
    "CashFlowsFromUsedInOperatingActivities": "Cash flows from operating activities",
    "CashFlowsFromUsedInInvestingActivities": "Cash flows from investing activities",
    "CashFlowsFromUsedInFinancingActivities": "Cash flows from financing activities",
    "IncreaseDecreaseInCashAndCashEquivalents": "Net increase in cash",
    "DividendsPaid": "Dividends paid",
    "InterestPaid": "Interest paid",
}


def _parse_xbrl_value(val) -> float | None:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).replace(",", "").replace(" ", "").strip()
    if not s or s in ("", "nan", "None"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _fetch_filings_sync(lei: str, api_base: str, proxy_url: str | None) -> list[dict]:
    url = f"{api_base}/api/filings"
    params = {"lei": lei, "limit": 20}
    transport = None
    if proxy_url:
        transport = httpx.HTTPTransport(proxy=proxy_url, verify=False)

    with httpx.Client(transport=transport, verify=False, timeout=60) as client:
        resp = client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

    filings = data.get("data", data) if isinstance(data, dict) else data
    if not isinstance(filings, list):
        return []

    result = []
    for f in filings:
        period_end = f.get("period_end") or f.get("period", {}).get("endDate", "")
        result.append({
            "id": f.get("id") or f.get("fxo_id"),
            "entity_name": f.get("entity_name") or f.get("entity", {}).get("name", ""),
            "period_end": period_end,
            "country": f.get("country") or f.get("entity", {}).get("country", ""),
            "url": f.get("package_url") or f.get("report_url", ""),
            "json_url": f.get("json_url", ""),
        })

    result.sort(key=lambda x: x.get("period_end", ""), reverse=True)
    return result


def _fetch_xbrl_facts_sync(filing: dict, api_base: str, proxy_url: str | None) -> list[dict]:
    json_url = filing.get("json_url", "")
    if not json_url:
        filing_id = filing.get("id", "")
        json_url = f"{api_base}/api/filings/{filing_id}/facts"

    transport = None
    if proxy_url:
        transport = httpx.HTTPTransport(proxy=proxy_url, verify=False)

    with httpx.Client(transport=transport, verify=False, timeout=120) as client:
        resp = client.get(json_url)
        resp.raise_for_status()
        data = resp.json()

    facts_raw = data.get("facts", data) if isinstance(data, dict) else data
    if not isinstance(facts_raw, (list, dict)):
        return []

    if isinstance(facts_raw, dict):
        parsed = []
        for concept_full, fact_list in facts_raw.items():
            if not isinstance(fact_list, list):
                fact_list = [fact_list]
            for fact in fact_list:
                if not isinstance(fact, dict):
                    continue
                concept_short = concept_full.split(":")[-1]
                period = fact.get("period", {})
                period_end = period.get("endDate") or period.get("instant", "")
                period_start = period.get("startDate", "")
                is_instant = "instant" in period
                fy_match = re.search(r"(\d{4})", period_end)
                fy_year = int(fy_match.group(1)) if fy_match else None

                parsed.append({
                    "concept_short": concept_short,
                    "concept_full": concept_full,
                    "period_type": "instant" if is_instant else "duration",
                    "period_start": period_start,
                    "period_end": period_end,
                    "fy_year": fy_year,
                    "value": fact.get("value"),
                    "unit": fact.get("unit"),
                    "decimals": fact.get("decimals"),
                })
        return parsed

    return facts_raw


def _build_statements(facts: list[dict], target_year: int) -> dict[str, list[dict]]:
    statements: dict[str, list[dict]] = {
        "income_statement": [],
        "balance_sheet": [],
        "cash_flow": [],
    }

    seen: dict[str, dict[str, float]] = {}

    years = {target_year, target_year - 1}

    for fact in facts:
        concept = fact.get("concept_short", "")
        fy = fact.get("fy_year")
        if not concept or fy not in years:
            continue

        stmt_type = STATEMENT_MAP.get(concept)
        if not stmt_type:
            continue

        val = _parse_xbrl_value(fact.get("value"))
        if val is None:
            continue

        key = f"{stmt_type}::{concept}"
        if key not in seen:
            seen[key] = {}
        seen[key][str(fy)] = val

    for key, year_vals in seen.items():
        stmt_type, concept = key.split("::", 1)
        label = CONCEPT_LABELS.get(concept, concept)
        row: dict[str, Any] = {"label": label}
        row.update(year_vals)
        statements[stmt_type].append(row)

    return statements


def _fetch_sync(lei: str, year: int) -> dict:
    api_base = settings.XBRL_API_BASE
    proxy_url = settings.http_proxy_url

    logger.info("Fetching XBRL filings for LEI=%s, year=%d", lei, year)

    filings = _fetch_filings_sync(lei, api_base, proxy_url)
    if not filings:
        raise ValueError(f"No XBRL filings found for LEI {lei}")

    target_filing = None
    for f in filings:
        period_end = f.get("period_end", "")
        m = re.search(r"(\d{4})", period_end)
        if m and int(m.group(1)) == year:
            target_filing = f
            break

    if not target_filing:
        logger.warning("No filing for year %d, using most recent", year)
        target_filing = filings[0]

    logger.info("Using filing: %s (period_end=%s)",
                target_filing.get("entity_name"), target_filing.get("period_end"))

    facts = _fetch_xbrl_facts_sync(target_filing, api_base, proxy_url)
    logger.info("Fetched %d XBRL facts", len(facts))

    statements = _build_statements(facts, year)

    result = {}
    for stmt_type, rows in statements.items():
        result[stmt_type] = {
            "rows": rows,
            "year_headers": [str(year), str(year - 1)],
            "unit_scale": None,
        }

    return result


async def fetch_xbrl_financials(lei: str, year: int) -> dict:
    result = await asyncio.to_thread(_fetch_sync, lei, year)

    for key in ("income_statement", "balance_sheet", "cash_flow"):
        if result.get(key) is None:
            result[key] = {
                "rows": [],
                "year_headers": [str(year), str(year - 1)],
                "unit_scale": None,
            }

    logger.info(
        "XBRL extraction complete: IS=%d rows, BS=%d rows, CF=%d rows",
        len(result["income_statement"]["rows"]),
        len(result["balance_sheet"]["rows"]),
        len(result["cash_flow"]["rows"]),
    )
    return result
